POCKET TYCOON - iPhone install guide

This is an installable web app (PWA). iPhones install PWAs from Safari.
A secure HTTPS website is required; opening index.html as a file is not enough.

EASIEST FREE HOSTING: GitHub Pages
1. On a computer, sign in to GitHub and create a new PUBLIC repository named pocket-tycoon.
2. Upload every file in this folder to the repository root (index.html, manifest.json, sw.js, icon-192.png, icon-512.png).
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch, select main and / (root), then Save.
5. Wait for GitHub Pages to publish. Your address will look like:
   https://YOUR-USERNAME.github.io/pocket-tycoon/
6. On your iPhone, open that address in Safari.
7. Tap Share (square with arrow) > Add to Home Screen > Add.

The game saves progress on the same iPhone/browser using local storage.
